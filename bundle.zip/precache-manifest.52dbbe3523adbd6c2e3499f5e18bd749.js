self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7989ba324ec1e2f16141ba3e5143c8fe",
    "url": "/index.html"
  },
  {
    "revision": "d718ef769ba7f1c72390",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "50833d80f6c66d1157fb",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "d718ef769ba7f1c72390",
    "url": "/static/js/2.4f509af7.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.4f509af7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "50833d80f6c66d1157fb",
    "url": "/static/js/main.6e26535c.chunk.js"
  },
  {
    "revision": "fe3ad462c10117cc9eb1",
    "url": "/static/js/runtime-main.96e822c6.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);